class LineAnalyzer

attr_reader :highest_wf_count

attr_reader :highest_wf_words

attr_reader :content

attr_reader :line_number

def initialize(content, line_number)

@content = content

@line_number = line_number

calculate_word_frequency

end

def calculate_word_frequency

@highest_wf_count = 0

@highest_wf_words = []

temp_words = {}

mcontent = @content.downcase.split

mcontent.each do |word|

temp_words[word] = mcontent.count(word)

end

@highest_wf_count = temp_words.values.max

if temp_words.values.count(@highest_wf_count) == temp_words.values.length

@highest_wf_words.concat(temp_words.keys)

elsif temp_words.values.count(@highest_wf_count) != 1

index = 0

temp_words.values.each do |hf|

if hf == @highest_wf_count

@highest_wf_words << temp_words.keys[index]

end

index += 1

end

else

index = temp_words.values.index(@highest_wf_count)

@highest_wf_words << temp_words.keys[index]

end

end

end

class Solution

attr_reader :analyzers

attr_reader :highest_count_across_lines

attr_reader :highest_count_words_across_lines

def initialize

@analyzers = []

end

def analyze_file

line_number = 1

if File.exist?('test.txt')

file = File.open("test.txt", "r") do |f|

f.each_line do |line|

@analyzers << LineAnalyzer.new(line, line_number)

line_number += 1

end

end

end

end

def calculate_line_with_highest_frequency

temp_array = []

@highest_count_words_across_lines = []

@analyzers.each do |obj|

temp_array << obj.highest_wf_count

end

@highest_count_across_lines = temp_array.max

@analyzers.each do |obj|

if obj.highest_wf_count == @highest_count_across_lines

@highest_count_words_across_lines << obj

end

end

end

def print_highest_word_frequency_across_lines

@highest_count_words_across_lines.each do |obj|

puts "#{obj.highest_wf_words} (appears in line #{obj.line_number})"

end

end

end

